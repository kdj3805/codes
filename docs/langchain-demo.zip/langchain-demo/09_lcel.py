from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Local LLM
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)

parser = StrOutputParser()

# 1. Simple chain
chain = (
    ChatPromptTemplate.from_template(
        "Translate the following text to French. Return only the translated text.\n\n{text}"
    )
    | llm
    | parser
)

print("=== SINGLE INVOKE ===")
print(chain.invoke({"text": "LangChain makes AI apps easy."}))
print("-" * 50)

# 2. Batch
print("=== BATCH ===")
results = chain.batch([
    {"text": "Hello"},
    {"text": "Goodbye"}
])
for r in results:
    print(r)
print("-" * 50)

# 3. Stream
print("=== STREAM ===")
for chunk in chain.stream({"text": "Streaming is powerful."}):
    print(chunk, end="")
print("\n" + "-" * 50)

# 4. Paragraph chain
paragraph_chain = (
    ChatPromptTemplate.from_template(
        "Write a short paragraph in 4 lines about {topic}. Return only the paragraph."
    )
    | llm
    | parser
)

print("=== PARAGRAPH CHAIN ===")
print(paragraph_chain.invoke({"topic": "AI agents"}))