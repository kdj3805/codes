from langchain_text_splitters import RecursiveCharacterTextSplitter, TokenTextSplitter

# Sample long text
text = "LangChain helps split large text into smaller chunks for LLM processing. " * 20

# ----------------------------------
# 1. RecursiveCharacterTextSplitter
# ----------------------------------
char_splitter = RecursiveCharacterTextSplitter(
    chunk_size=120,
    chunk_overlap=20
)

char_chunks = char_splitter.create_documents([text])

print("=== CHARACTER SPLITTER ===")
print("Total chunks:", len(char_chunks))
print("First chunk:")
print(char_chunks[0].page_content)
print("-" * 50)

# ----------------------------------
# 2. TokenTextSplitter
# ----------------------------------
token_splitter = TokenTextSplitter(
    chunk_size=30,
    chunk_overlap=5
)

token_chunks = token_splitter.create_documents([text])

print("=== TOKEN SPLITTER ===")
print("Total chunks:", len(token_chunks))
print("First chunk:")
print(token_chunks[0].page_content)
print("-" * 50)