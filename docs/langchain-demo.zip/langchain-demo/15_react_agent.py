from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from langchain_core.tools import tool
import math
import datetime

llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)

@tool
def calculate(expression: str) -> str:
    """Evaluate a math expression."""
    return str(eval(expression, {"__builtins__": {}}, {"math": math}))

@tool
def get_date() -> str:
    """Return today's date."""
    return datetime.date.today().isoformat()

agent = create_agent(
    model=llm,
    tools=[calculate, get_date],
    system_prompt=(
        "You are a helpful assistant. "
        "For date questions, always use the get_date tool. "
        "For math questions, always use the calculate tool. "
        "Do not guess."
    )
)

result = agent.invoke({
    "messages": [
        {
            "role": "user",
            "content": "What is today's date and what is math.sqrt(2025)?"
        }
    ]
})

print(result["messages"][-1].content)