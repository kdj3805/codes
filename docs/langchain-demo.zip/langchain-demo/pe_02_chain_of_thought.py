from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
# ── Local LLM Configuration ────────────────────────────────────
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.37.1:1234/v1",
    api_key="lm-studio",
    temperature=0.0,
    max_tokens=512,
)
# ── Example 1: Zero-shot Step-by-Step Prompting ────────────────
print("\n--- Example 1: Zero-shot CoT ---")
cot_prompt = ChatPromptTemplate.from_messages([
    ("system", "Think step by step and keep the answer simple."),
    ("human", "Solve this problem: {problem}"),
])
cot_chain = cot_prompt | llm | StrOutputParser()
problems = [
    "If a car travels 60 km in 2 hours, what is its speed per hour?",
    "What is 15 + 27?",
]
for p in problems:
    print(f"\nProblem: {p}")
    print(cot_chain.invoke({"problem": p}))
# ── Example 2: Few-shot Prompting ──────────────────────────────
print("\n--- Example 2: Few-shot CoT ---")
few_shot_prompt = ChatPromptTemplate.from_messages([
    ("system", "Solve the problem step by step like the example."),
    (
        "human",
        "Example:\n"
        "Q: 10 mangoes cost 50 rupees. What is the cost of 1 mango?\n"
        "A: 1 mango costs 50 / 10 = 5 rupees. Final Answer: 5 rupees."
    ),
    ("ai", "Okay, I will follow the same style."),
    ("human", "Now solve this:\nQ: {question}"),
])
few_shot_chain = few_shot_prompt | llm | StrOutputParser()
result = few_shot_chain.invoke({
    "question": "6 notebooks cost 120 rupees. What is the cost of 1 notebook?"
})
print(result)