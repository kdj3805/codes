from langchain_community.tools import DuckDuckGoSearchRun, WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

# -----------------------------
# 1. DuckDuckGo Search
# -----------------------------
search = DuckDuckGoSearchRun()

print("=== DUCKDUCKGO SEARCH ===")
try:
    result = search.invoke("What is LangChain?")
    print(result[:300])
except Exception as e:
    print("Search error:", e)

print("-" * 50)

# -----------------------------
# 2. Wikipedia Search
# -----------------------------
wiki = WikipediaQueryRun(
    api_wrapper=WikipediaAPIWrapper(top_k_results=1)
)

print("=== WIKIPEDIA SEARCH ===")
try:
    result = wiki.invoke("Retrieval-Augmented Generation")
    print(result[:300])
except Exception as e:
    print("Wikipedia error:", e)