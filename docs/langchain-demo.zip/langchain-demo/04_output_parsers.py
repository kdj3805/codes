from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser, CommaSeparatedListOutputParser

# Create connection to local LLM
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.37.1:1234/v1",
    api_key="lm-studio",
    temperature=0.0,
    max_tokens=256,
)

# ---------------------------------------------------------------
# Example 1: String output
# ---------------------------------------------------------------
print("\n--- Example 1: StrOutputParser ---")

# Create prompt
prompt1 = PromptTemplate.from_template(
    "What is {item}? Explain in 1 simple sentence."
)

# Build chain: Prompt -> LLM -> Output Parser
chain1 = prompt1 | llm | StrOutputParser()

# Run chain
output1 = chain1.invoke({"item": "Vector Database"})

# Print result
print(output1)

# ---------------------------------------------------------------
# Example 2: List output
# ---------------------------------------------------------------
print("\n--- Example 2: CommaSeparatedListOutputParser ---")

# Create list parser
list_parser = CommaSeparatedListOutputParser()

# Create prompt with parser instructions
prompt2 = PromptTemplate(
    template=(
        "Name 5 cloud platforms.\n"
        "{format_instructions}"
    ),
    input_variables=[],
    partial_variables={
        "format_instructions": list_parser.get_format_instructions()
    },
)

# Build chain
chain2 = prompt2 | llm | list_parser

# Run chain
output2 = chain2.invoke({})

# Print result
print(output2)