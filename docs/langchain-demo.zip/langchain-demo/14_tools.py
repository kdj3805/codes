import math
import datetime
from langchain_core.tools import tool

# 1. Current date and time
@tool
def get_datetime() -> str:
    """Return the current date and time."""
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

# 2. Simple calculator
@tool
def calculate(expression: str) -> str:
    """Evaluate a math expression."""
    return str(eval(expression, {"__builtins__": {}}, {"math": math}))

# 3. Word count
@tool
def word_count(text: str) -> str:
    """Count words in the given text."""
    return str(len(text.split()))

# -----------------------------------
# Test tools directly
# -----------------------------------
print("=== DATETIME TOOL ===")
print("Output      :", get_datetime.invoke({}))
print("Name        :", get_datetime.name)
print("Description :", get_datetime.description)
print("-" * 50)

print("=== CALCULATOR TOOL ===")
print("Output      :", calculate.invoke({"expression": "math.sqrt(144) + 10"}))
print("Name        :", calculate.name)
print("Description :", calculate.description)
print("-" * 50)

print("=== WORD COUNT TOOL ===")
print("Output      :", word_count.invoke({"text": "Hello world from LangChain tools"}))
print("Name        :", word_count.name)
print("Description :", word_count.description)
print("-" * 50)