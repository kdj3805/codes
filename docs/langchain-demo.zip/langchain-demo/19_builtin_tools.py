from langchain_community.document_loaders import YoutubeLoader

loader = YoutubeLoader.from_youtube_url(
    "https://www.youtube.com/watch?v=UTMeTvlG7Nc",
    add_video_info=False
)

docs = loader.load()
print(docs[0].page_content[:4000])