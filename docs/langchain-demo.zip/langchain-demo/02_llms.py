from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.37.1:1234/v1",
    api_key="lm-studio",
    temperature=0.7,
    max_tokens=512,
)

# ── Single call ────────────────────────────────────────────────
response = llm.invoke("List 3 use cases of LangChain:")
print(response.content)

# ── Batch ──────────────────────────────────────────────────────
responses = llm.batch(["Capital of France?", "Capital of Japan?"])
for r in responses:
    print(r.content.strip())

# ── Streaming ──────────────────────────────────────────────────
for chunk in llm.stream("Explain embeddings in one paragraph:"):
    if chunk.content:
        print(chunk.content, end="", flush=True)

print()  