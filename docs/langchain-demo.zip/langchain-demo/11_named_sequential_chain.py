from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Local LLM
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)

parser = StrOutputParser()

# Step 1: pain points
step1 = (
    PromptTemplate.from_template(
        "List 3 pain points in the {domain} industry. Keep it short."
    )
    | llm
    | parser
)

# Step 2: AI solutions
step2 = (
    PromptTemplate.from_template(
        "Pain points:\n{pain_points}\n\n"
        "Suggest one AI solution for each pain point. Keep it short."
    )
    | llm
    | parser
)

# Step 3: executive summary
step3 = (
    PromptTemplate.from_template(
        "Domain: {domain}\n"
        "Solutions:\n{solutions}\n\n"
        "Write a short 2-sentence executive summary."
    )
    | llm
    | parser
)

# Run step by step
domain = "banking"

pain_points = step1.invoke({"domain": domain})
solutions = step2.invoke({"pain_points": pain_points})
executive_summary = step3.invoke({
    "domain": domain,
    "solutions": solutions
})

print("=== PAIN POINTS ===")
print(pain_points)
print("-" * 50)

print("=== AI SOLUTIONS ===")
print(solutions)
print("-" * 50)

print("=== EXECUTIVE SUMMARY ===")
print(executive_summary)