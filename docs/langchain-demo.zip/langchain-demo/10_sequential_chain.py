from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Local LLM
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)

parser = StrOutputParser()

# Step 1: generate product idea
step1 = (
    PromptTemplate.from_template(
        "Suggest one simple AI product idea for {industry}. Return only one sentence."
    )
    | llm
    | parser
)

# Step 2: generate short investor pitch
step2 = (
    PromptTemplate.from_template(
        "Write a short 3-sentence investor pitch for this product idea:\n\n{idea}\n\nReturn only the pitch."
    )
    | llm
    | parser
)

# Run sequentially
industry = "healthcare"
idea = step1.invoke({"industry": industry})
pitch = step2.invoke({"idea": idea})

print("=== PRODUCT IDEA ===")
print(idea)
print("-" * 50)
print("=== INVESTOR PITCH ===")
print(pitch)