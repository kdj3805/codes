from langchain_core.prompts import PromptTemplate, ChatPromptTemplate

# ── 1. Basic PromptTemplate ────────────────────────────────────
template = PromptTemplate.from_template(
    "Explain {topic} to a {audience} in 2 sentences."
)

result = template.format(topic="RAG pipelines", audience="product manager")
print("Basic PromptTemplate Output:")
print(result)
print("-" * 50)


# ── 2. ChatPromptTemplate ──────────────────────────────────────
chat_prompt = ChatPromptTemplate.from_messages([
    ("system", "You are an expert in {domain}."),
    ("human", "Give me 3 best practices for {task}."),
])

msgs = chat_prompt.format_messages(domain="RAG", task="chunking documents")

print("ChatPromptTemplate Output:")
for m in msgs:
    print(f"[{m.type}] {m.content}")
print("-" * 50)


# ── 3. Simple Few-Shot Prompting  ──────────────────
examples = """
Word: happy
Antonym: sad

Word: fast
Antonym: slow
"""

few_shot_prompt = f"""
Give the antonym of every word.

{examples}

Word: bright
Antonym:
"""

print("Simple Few-Shot Prompt Output:")
print(few_shot_prompt)