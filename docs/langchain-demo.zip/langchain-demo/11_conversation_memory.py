from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)

history = [
    SystemMessage(content="You are a helpful assistant. Give short and direct answers.")
]

turns = [
    "My name is Mohan and I am a GenAI Architect.",
    "What role do I work in?",
    "What skills does someone in my role need?",
]

for turn in turns:
    history.append(HumanMessage(content=turn))
    response = llm.invoke(history)
    history.append(AIMessage(content=response.content))

    print(f"Human: {turn}")
    print(f"AI   : {response.content}\n")