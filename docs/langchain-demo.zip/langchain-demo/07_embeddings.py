import numpy as np
from sentence_transformers import SentenceTransformer

# Load local embedding model
model = SentenceTransformer("all-MiniLM-L6-v2")

texts = [
    "LangChain is a framework for building LLM applications.",
    "Vector databases store embeddings for semantic search.",
    "Paris is the capital of France."
]

query = "What is LangChain?"

# Create embeddings
doc_vectors = model.encode(texts)
query_vector = model.encode(query)

print("Vector dimension:", len(doc_vectors[0]))
print("-" * 50)

# Cosine similarity
def cosine_similarity(a, b):
    a = np.array(a)
    b = np.array(b)
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

print("Query:", query)
print("\nSimilarity scores:")
for text, vector in zip(texts, doc_vectors):
    score = cosine_similarity(query_vector, vector)
    print(f"{score:.3f}  ->  {text}")