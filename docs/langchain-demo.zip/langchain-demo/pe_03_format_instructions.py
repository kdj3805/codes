from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)
prompt = PromptTemplate.from_template(
    """
Review this product: {product}

Return only valid JSON with keys:
product, pros, cons, score, verdict

Example format:
{{
  "product": "some product",
  "pros": ["pro1", "pro2"],
  "cons": ["con1", "con2"],
  "score": 8.5,
  "verdict": "Short final opinion"
}}
"""
)
chain = prompt | llm

result = chain.invoke(
    {"product": "LangChain for building RAG applications"}
)
print(result.content)