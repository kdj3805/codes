from langchain_community.document_loaders import TextLoader, CSVLoader, WebBaseLoader
# -----------------------------
# 1. Load text file
# -----------------------------
text_docs = TextLoader("notes.txt").load()

print("=== TEXT LOADER ===")
print("Content preview:")
print(text_docs[0].page_content[:200])
print("Metadata:")
print(text_docs[0].metadata)
print("-" * 50)


# -----------------------------
# 2. Load CSV file
# Each row becomes one Document
# -----------------------------
csv_docs = CSVLoader("data.csv").load()

print("=== CSV LOADER ===")
print("Total rows loaded:", len(csv_docs))
print("First row content:")
print(csv_docs[0].page_content)
print("First row metadata:")
print(csv_docs[0].metadata)
print("-" * 50)


# -----------------------------
# 3. Load web page
# -----------------------------
web_docs = WebBaseLoader("https://python.langchain.com/docs/introduction/").load()

print("=== WEB LOADER ===")
print("Web content preview:")
print(web_docs[0].page_content[:300])
print("Metadata:")
print(web_docs[0].metadata)
print("-" * 50)