from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

chat = ChatOpenAI(
    model="gpt-4o-mini",
    api_key="YOUR_OPENAI_API_KEY",
    temperature=0.7,
    max_tokens=512,
)

messages = [
    SystemMessage(content="You are a concise technical assistant."),
    HumanMessage(content="What is LangChain?"),
    AIMessage(content="LangChain is a framework for building LLM apps."),
    HumanMessage(content="Name its 3 core modules."),
]

response = chat.invoke(messages)
print(response.content)