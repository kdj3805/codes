from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate
from langchain_core.output_parsers import StrOutputParser

llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)

# -----------------------------
# Few-shot examples
# -----------------------------
examples = [
    {
        "input": "The server is down and users can't login.",
        "output": "SEVERITY: High | CATEGORY: Availability | ACTION: Escalate to on-call engineer"
    },
    {
        "input": "The dashboard loads 2 seconds slower than last week.",
        "output": "SEVERITY: Medium | CATEGORY: Performance | ACTION: Check DB queries"
    },
]

example_prompt = ChatPromptTemplate.from_messages([
    ("human", "{input}"),
    ("ai", "{output}")
])

few_shot_prompt = FewShotChatMessagePromptTemplate(
    examples=examples,
    example_prompt=example_prompt
)

# -----------------------------
# Main prompt
# -----------------------------
final_prompt = ChatPromptTemplate.from_messages([
    (
        "system",
        "You are an SRE assistant. "
        "Classify the incident and return only this format:\n"
        "SEVERITY: <Low|Medium|High> | CATEGORY: <type> | ACTION: <next step>"
    ),
    few_shot_prompt,
    ("human", "{incident}")
])

# -----------------------------
# Chain
# -----------------------------
chain = final_prompt | llm | StrOutputParser()

# -----------------------------
# Test incidents
# -----------------------------
incidents = [
    "Memory usage at 95% on prod database for the past 10 minutes.",
    "A button label is misspelled on the settings page."
]

for incident in incidents:
    result = chain.invoke({"incident": incident})
    print("Incident :", incident)
    print("Decision :", result)
    print("-" * 60)