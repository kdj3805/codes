from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

chat = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.37.1:1234/v1",
    api_key="lm-studio",
    temperature=0.7,  #lower value like 0.0 → more deterministic, stable, direct 
    max_tokens=512,
)

messages = [
    SystemMessage(content="You are a concise technical assistant."),
    HumanMessage(content="What is LangChain?"),
    AIMessage(content="LangChain is a framework for building LLM apps."),
    HumanMessage(content="Name its 3 core modules."),
]

response = chat.invoke(messages)
print(response.content)