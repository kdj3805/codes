from langchain_openai import ChatOpenAI
from langchain_classic.chains import ConversationChain
from langchain_classic.memory import (
    ConversationBufferMemory,
    ConversationBufferWindowMemory,
)

# -----------------------------------
# Local LLM
# -----------------------------------
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.224.1:1234/v1",
    api_key="lm-studio",
    temperature=0
)

# -----------------------------------
# ConversationBufferMemory demo
# -----------------------------------
memory = ConversationBufferMemory(return_messages=True)

chat = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=False
)

turns = [
    "Hi! My name is Mohan. I am building a RAG chatbot.",
    "What tech stack would you recommend for my project?",
    "What was the first thing I told you?"
]

print("=== CONVERSATION BUFFER MEMORY ===")
for turn in turns:
    reply = chat.predict(input=turn)
    print(f"Human: {turn}")
    print(f"AI   : {reply}\n")

print("Total messages stored in memory:", len(memory.chat_memory.messages))
print("-" * 60)

# -----------------------------------
# ConversationBufferWindowMemory demo
# -----------------------------------
window_memory = ConversationBufferWindowMemory(k=3)

window_chat = ConversationChain(
    llm=llm,
    memory=window_memory,
    verbose=False
)

window_turns = [
    "My name is Mohan.",
    "I am learning LangChain.",
    "I am building a chatbot.",
    "I like Python.",
    "What do you still remember about me?"
]

print("=== CONVERSATION BUFFER WINDOW MEMORY ===")
for turn in window_turns:
    reply = window_chat.predict(input=turn)
    print(f"Human: {turn}")
    print(f"AI   : {reply}\n")

print("Window memory keeps only the latest 3 turns.")