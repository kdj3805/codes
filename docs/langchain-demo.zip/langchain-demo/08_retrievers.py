from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

# Local embedding model
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# Sample texts
texts = [
    "LangChain provides modular components for LLM applications.",
    "RAG combines retrieval with generation to produce grounded answers.",
    "FAISS is a vector store used for semantic search.",
    "Agents can use tools to complete tasks automatically."
]

# Create FAISS vector store
vector_store = FAISS.from_texts(texts, embeddings)

# Query
query = "What is RAG?"
results = vector_store.similarity_search(query, k=2)

print("=== FAISS RETRIEVER DEMO ===")
print("Query:", query)
print("-" * 50)
print("Top matching texts:")

for i, doc in enumerate(results, 1):
    print(f"{i}. {doc.page_content}")