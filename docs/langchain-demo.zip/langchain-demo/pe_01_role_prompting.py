from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
# ── Local LLM Configuration ────────────────────────────────────
llm = ChatOpenAI(
    model="meta-llama-3.1-8b-instruct",
    base_url="http://192.168.37.1:1234/v1",
    api_key="lm-studio",
    temperature=0.0,
    max_tokens=512,
)
# ── Role: Senior Security Auditor ──────────────────────────────
prompt = ChatPromptTemplate.from_messages([
    (
        "system",
        "You are a senior cybersecurity auditor with 15 years of experience. "
        "Respond with precise, actionable findings only. No fluff."
    ),
    (
        "human",
        "Review this practice: {practice}"
    ),
])
chain = prompt | llm | StrOutputParser()
print("\n--- Security Auditor Output ---")
print(chain.invoke({
    "practice": "We store API keys in environment variables on a shared dev server."
}))
# ── Role: Friendly Explainer ───────────────────────────────────
simple_prompt = ChatPromptTemplate.from_messages([
    (
        "system",
        "You are a patient teacher explaining complex topics to a 10-year-old. "
        "Use simple words and fun analogies."
    ),
    (
        "human",
        "Explain: {topic}"
    ),
])
simple_chain = simple_prompt | llm | StrOutputParser()
print("\n--- Friendly Explainer Output ---")
print(simple_chain.invoke({
    "topic": "How does a RAG pipeline work?"
}))