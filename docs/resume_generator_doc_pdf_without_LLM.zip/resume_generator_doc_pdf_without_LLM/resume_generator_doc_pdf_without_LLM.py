import random
from faker import Faker
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os
from pdfkit import from_file
import tempfile
from datetime import datetime, timedelta

# Initialize Faker
fake = Faker()

# Configuration
NUM_RESUMES = 10  # Configurable number of resumes to generate

# Indian names data
INDIAN_FIRST_NAMES = [
    "Aarav", "Aditya", "Akshay", "Amit", "Aniket", "Arjun", "Dhruv", "Gaurav", 
    "Harsh", "Ishaan", "Karan", "Manish", "Nikhil", "Pranav", "Rahul", "Rajat",
    "Rohit", "Sachin", "Sandeep", "Sanjay", "Varun", "Vikram", "Vishal", "Yash",
    "Aanya", "Ananya", "Divya", "Ishita", "Kavita", "Meera", "Neha", "Pooja",
    "Priya", "Riya", "Shreya", "Sneha", "Tanvi", "Trisha", "Urvashi", "Vaishnavi"
]

INDIAN_LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Malhotra", "Patel", "Reddy", "Kumar", "Singh",
    "Mehta", "Joshi", "Choudhary", "Deshmukh", "Naidu", "Iyengar", "Menon",
    "Nair", "Pillai", "Chatterjee", "Banerjee", "Mukherjee", "Das", "Bose",
    "Ghosh", "Sen", "Rao", "Chauhan", "Yadav", "Pawar", "Thakur", "Rathod"
]

# Template components
ROLES = [
    "Technical Architect - Kubernetes & Generative AI", 
    "Tech Lead - Data Science", 
    "Generative AI Specialist",
    "Senior AI/ML Engineer", 
    "Cloud Solutions Architect",
    "Data Science Manager"
]

COMPANIES = [
    "AI Leader X", "GenAI Labs", "DataTech Innovations", 
    "CloudNative Solutions", "ML Horizon", "Deep Learning India"
]

INDIAN_CITIES = [
    "New Delhi", "Bangalore", "Hyderabad", "Mumbai", "Chennai", "Pune"
]

TECH_STACKS = {
    "Technical Architect - Kubernetes & Generative AI": [
        "Kubernetes", "OpenShift", "AWS/GCP", "Terraform", "Helm", "Prometheus", 
        "GPT-4", "LangChain", "Diffusion Models", "Kubeflow", "Istio", "KNative"
    ],
    "Tech Lead - Data Science": [
        "Python", "PySpark", "TensorFlow", "XGBoost", "LightGBM", "MLflow", 
        "AWS SageMaker", "Azure Databricks", "Kafka", "Neo4j", "Kubernetes"
    ],
    "Generative AI Specialist": [
        "GPT-4", "GANs", "Diffusion Models", "LLM Fine-Tuning", "Hugging Face", 
        "LangChain", "Stable Diffusion", "TensorFlow", "PyTorch", "Azure ML"
    ],
    "Senior AI/ML Engineer": [
        "Python", "TensorFlow", "PyTorch", "Scikit-learn", "OpenCV", 
        "NLP (NLTK, spaCy)", "Keras", "AWS SageMaker", "MLflow"
    ],
    "Cloud Solutions Architect": [
        "AWS", "Azure", "GCP", "Terraform", "Docker", "Kubernetes", 
        "Serverless", "CI/CD", "Microservices", "Cloud Security"
    ],
    "Data Science Manager": [
        "Python", "SQL", "Big Data", "Machine Learning", "Deep Learning", 
        "Data Visualization", "Team Leadership", "Project Management"
    ]
}

CERTIFICATIONS = {
    "Technical Architect - Kubernetes & Generative AI": [
        "Certified Kubernetes Administrator (CKA)", 
        "Red Hat Certified Architect (RHCA) - OpenShift",
        "AWS Certified Solutions Architect - Professional",
        "NVIDIA Deep Learning Institute (Generative AI)"
    ],
    "Tech Lead - Data Science": [
        "AWS Certified Data Analytics - Specialty", 
        "TensorFlow Developer Certification",
        "Microsoft Certified: Azure Data Scientist",
        "Google Professional Data Engineer"
    ],
    "Generative AI Specialist": [
        "TensorFlow Developer Certified", 
        "AWS Certified Machine Learning Specialty",
        "DeepLearning.AI Generative AI Specialization",
        "NVIDIA DLI Certifications"
    ],
    "Senior AI/ML Engineer": [
        "TensorFlow Developer Certificate", 
        "AWS Certified Machine Learning Specialty",
        "Google Professional Machine Learning Engineer",
        "Microsoft Certified: Azure AI Engineer"
    ],
    "Cloud Solutions Architect": [
        "AWS Certified Solutions Architect - Professional",
        "Google Professional Cloud Architect",
        "Microsoft Certified: Azure Solutions Architect Expert",
        "Red Hat Certified Architect"
    ],
    "Data Science Manager": [
        "IBM Data Science Professional Certificate",
        "Microsoft Certified: Azure AI Engineer",
        "Google Data Analytics Professional Certificate",
        "AWS Certified Machine Learning Specialty"
    ]
}

EDUCATION = {
    "Technical Architect - Kubernetes & Generative AI": [
        "Master of Science in Computer Science",
        "Bachelor of Technology in Computer Science"
    ],
    "Tech Lead - Data Science": [
        "Master of Science in Computer Science",
        "Bachelor of Technology in Computer Science"
    ],
    "Generative AI Specialist": [
        "Master of Science in Computer Science",
        "Bachelor of Science in Computer Science"
    ]
}

INDIAN_UNIVERSITIES = {
    "Master": [
        "Indian Institute of Science (IISc), Bangalore",
        "Indian Institute of Technology (IIT), Delhi",
        "University of Technology, Delhi"
    ],
    "Bachelor": [
        "National Institute of Technology (NIT), Delhi",
        "Delhi Technological University",
        "Delhi Institute of Engineering"
    ]
}

DOMAINS = ["aileaderx.com", "gmail.com", "outlook.com"]

PROJECT_DESCRIPTIONS = {
    "Technical Architect - Kubernetes & Generative AI": [
        "Architected a multi-cloud Kubernetes platform managing 10K+ nodes for a global fintech client",
        "Led migration of legacy monolithic apps to Red Hat OpenShift for a healthcare giant",
        "Designed a Kubernetes-hosted LLM (GPT-4) platform generating personalized marketing content"
    ],
    "Tech Lead - Data Science": [
        "Built a machine learning model to predict equipment failures using sensor data",
        "Developed an ensemble model for telecom customer churn prediction",
        "Architected a deep learning-based fraud detection pipeline processing 1M+ transactions/day"
    ],
    "Generative AI Specialist": [
        "Led development of a GPT-based text generation system for automated customer support",
        "Designed a conditional GAN to generate synthetic MRI scans for rare disease training",
        "Architected a diffusion-based model for joint text-image generation for marketing"
    ]
}

PROJECT_TECH_STACKS = {
    "Technical Architect - Kubernetes & Generative AI": [
        ["Kubernetes", "Helm", "Prometheus", "Grafana", "AWS EKS", "Terraform"],
        ["OpenShift", "Operators", "Istio", "Quarkus", "Ansible"],
        ["GPT-4", "Stable Diffusion", "Kubeflow", "KNative", "NVIDIA DGX"]
    ],
    "Tech Lead - Data Science": [
        ["Python", "Scikit-learn", "TensorFlow", "AWS SageMaker", "Tableau"],
        ["PySpark", "MLflow", "Power BI", "Azure Databricks"],
        ["TensorFlow", "Apache Kafka", "Neo4j", "Kubernetes", "Google Cloud"]
    ],
    "Generative AI Specialist": [
        ["Python", "Hugging Face Transformers", "AWS SageMaker", "Flask API"],
        ["PyTorch", "TensorFlow", "Medical Open Network for AI (MONAI)", "Docker"],
        ["Stable Diffusion", "LangChain", "Azure ML", "React.js"]
    ]
}

def set_docx_margins(doc, margin=Inches(0.5)):
    """Set document margins"""
    section = doc.sections[0]
    section.left_margin = margin
    section.right_margin = margin
    section.top_margin = margin
    section.bottom_margin = margin

def add_section_header(doc, title):
    """Add a section header with formatting"""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(title)
    run.bold = True
    run.font.size = Pt(12)
    run.font.name = 'Calibri'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Calibri')
    
    # Add bottom border
    p_border = OxmlElement('w:pBdr')
    p_pr = p._element.get_or_add_pPr()
    p_pr.append(p_border)
    
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '4')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), '4472C4')
    p_border.append(bottom)
    
    return p

def generate_indian_name():
    return f"{random.choice(INDIAN_FIRST_NAMES)} {random.choice(INDIAN_LAST_NAMES)}"

def generate_email(name, company):
    if company == "AI Leader X":
        return f"{name.lower().replace(' ', '.')}@aileaderx.com"
    else:
        domain = random.choice(DOMAINS)
        return f"{name.lower().replace(' ', '.')}@{domain}"

def generate_project_description(role):
    if role in PROJECT_DESCRIPTIONS:
        return random.choice(PROJECT_DESCRIPTIONS[role])
    else:
        return f"Led development of {random.choice(['enterprise', 'scalable', 'high-performance'])} {role.split()[0].lower()} {random.choice(['solution', 'system', 'application'])}"

def generate_project_tech_stack(role):
    if role in PROJECT_TECH_STACKS:
        return random.choice(PROJECT_TECH_STACKS[role])
    else:
        return random.sample(TECH_STACKS[role], k=random.randint(4, 6))

def generate_quantifiable_achievement(role):
    achievements = {
        "Technical Architect - Kubernetes & Generative AI": [
            f"Achieved {random.choice(['99.99%', '99.95%'])} uptime for mission-critical platform",
            f"Reduced cloud costs by ${random.randint(1, 5)}M/year through auto-scaling strategies",
            f"Improved system performance by {random.randint(30, 70)}% through architecture optimization",
            f"Led migration of {random.randint(50, 500)}+ applications to cloud-native architecture",
            f"Reduced deployment time by {random.randint(40, 80)}% through CI/CD automation"
        ],
        "Tech Lead - Data Science": [
            f"Achieved {random.randint(85, 95)}% accuracy in predictive model",
            f"Reduced {random.choice(['customer churn', 'fraud cases', 'equipment downtime'])} by {random.randint(20, 40)}%",
            f"Generated ${random.randint(1, 5)}M in cost savings through data-driven insights",
            f"Improved model performance by {random.randint(25, 50)}% through feature engineering",
            f"Reduced false positives by {random.randint(15, 30)}% in anomaly detection"
        ],
        "Generative AI Specialist": [
            f"Achieved {random.randint(85, 95)}% accuracy in {random.choice(['text generation', 'image synthesis', 'content creation'])}",
            f"Reduced {random.choice(['response time', 'content creation time', 'model training time'])} by {random.randint(30, 60)}%",
            f"Improved {random.choice(['engagement', 'conversion', 'accuracy'])} by {random.randint(20, 50)}%",
            f"Reduced {random.choice(['hallucinations', 'bias', 'errors'])} by {random.randint(25, 45)}%",
            f"Optimized GPU utilization achieving {random.randint(30, 50)}% cost efficiency"
        ]
    }
    
    if role in achievements:
        return random.choice(achievements[role])
    else:
        return f"Improved {random.choice(['performance', 'efficiency', 'accuracy'])} by {random.randint(20, 50)}%"

def generate_experience(role, years):
    experience = []
    current_date = datetime.now()
    
    total_years = years
    while total_years > 0:
        duration = random.randint(1, min(4, total_years))
        total_years -= duration
        
        start_date = current_date - timedelta(days=365*duration)
        end_date = start_date + timedelta(days=365*duration - 1) if duration < years else "Present"
        
        company = random.choice(COMPANIES)
        location = random.choice(INDIAN_CITIES)
        
        num_projects = random.randint(1, 2) if duration < 3 else 1
        projects = []
        for _ in range(num_projects):
            project_name = f"{role.split()[0]} {fake.word().capitalize()} {random.choice(['System', 'Platform', 'Framework'])}"
            tech_stack = generate_project_tech_stack(role)
            description = generate_project_description(role)
            
            contributions = [
                generate_quantifiable_achievement(role),
                f"Led a team of {random.randint(2, 8)} {random.choice(['engineers', 'data scientists', 'developers'])} to deliver the solution",
                f"Implemented {random.choice(['scalable', 'high-performance', 'secure'])} architecture using {random.choice(tech_stack)}",
                f"Presented results to {random.choice(['C-level executives', 'stakeholders', 'clients'])} with actionable insights",
                f"Optimized {random.choice(['performance', 'cost', 'accuracy'])} through {random.choice(['algorithm improvements', 'architecture changes', 'data pipeline enhancements'])}"
            ]
            
            projects.append({
                "name": project_name,
                "duration": f"{start_date.year - random.randint(0, 1)}-{start_date.year}",
                "description": description,
                "tech_stack": tech_stack,
                "contributions": random.sample(contributions, k=random.randint(2, 3))
            })
        
        experience.append({
            "company": company,
            "role": role,
            "location": location,
            "duration": f"{start_date.strftime('%b %Y')} - {end_date if isinstance(end_date, str) else end_date.strftime('%b %Y')}",
            "projects": projects
        })
    
    return experience

def generate_education(role):
    education = []
    
    if role in EDUCATION:
        degrees = EDUCATION[role]
    else:
        degrees = ["Master of Science in Computer Science", "Bachelor of Technology in Computer Science"]
    
    for degree in degrees:
        if "Master" in degree:
            university = random.choice(INDIAN_UNIVERSITIES["Master"])
            year = random.randint(2010, 2023)
            education.append({
                "degree": degree,
                "university": university,
                "year": f"{year} - {year + 2}"
            })
        else:
            university = random.choice(INDIAN_UNIVERSITIES["Bachelor"])
            year = random.randint(2005, 2015)
            education.append({
                "degree": degree,
                "university": university,
                "year": f"{year} - {year + 4}"
            })
    
    return education

def generate_resume():
    role = random.choice(ROLES)
    years_experience = random.randint(5, 15) if "Architect" in role or "Lead" in role else random.randint(3, 7)
    name = generate_indian_name()
    current_company = random.choice(COMPANIES)
    email = generate_email(name, current_company)
    phone = f"+91 {random.randint(7000000000, 9999999999)}"
    location = f"{random.choice(INDIAN_CITIES)}, India"
    
    education = generate_education(role)
    experience = generate_experience(role, years_experience)
    skills = TECH_STACKS[role]
    
    certifications = []
    if role in CERTIFICATIONS:
        available_certs = CERTIFICATIONS[role]
        max_certs = min(3, len(available_certs))  # Never try to sample more than available
        num_certs = random.randint(1, max_certs)
        certifications = random.sample(available_certs, k=num_certs)
    
    achievements = [
        f"Speaker at {random.choice(['KubeCon', 'NeurIPS', 'IEEE Conference', 'ACM Symposium'])} {random.randint(2020, 2023)}",
        f"Published paper in {random.choice(['IEEE', 'ACM', 'Springer'])} on '{fake.sentence(nb_words=4)[:-1]}'",
        f"Awarded '{random.choice(['AI Innovator', 'Architect of the Year', 'Tech Leader'])}' at {current_company}",
        f"Patented '{fake.sentence(nb_words=5)[:-1]}' technology",
        f"Mentored {random.randint(5, 15)} junior {random.choice(['engineers', 'data scientists', 'developers'])}"
    ]
    
    publications = []
    if random.random() > 0.7:  # 30% chance of having publications
        num_pubs = random.randint(1, 2)
        venues = ["IEEE Cloud Computing", "ACM SIGKDD", "Journal of AI Research", "Springer NLP Journal"]
        for _ in range(num_pubs):
            publications.append({
                "title": fake.sentence(nb_words=6)[:-1],
                "venue": random.choice(venues),
                "year": random.randint(2020, 2023)
            })
    
    summary = f"Visionary {role.split('-')[0].strip()} with {years_experience}+ years of experience in {random.choice(TECH_STACKS[role][:3])} and {random.choice(TECH_STACKS[role][3:6])}. "
    if "Architect" in role:
        summary += f"Led {random.randint(5, 15)}+ cross-functional teams to deliver mission-critical platforms for enterprise clients. "
    elif "Lead" in role:
        summary += f"Specialized in end-to-end data solutions and predictive analytics, driving ${random.randint(1, 5)}M+ in cost savings. "
    else:
        summary += f"Proven expertise in designing and deploying cutting-edge solutions improving operational efficiency by {random.randint(30, 50)}%. "
    
    summary += f"Recognized for {random.choice(['innovative solutions', 'technical leadership', 'scalable architectures'])} at {current_company}."
    
    return {
        "name": name,
        "role": role,
        "current_company": current_company,
        "contact": {
            "email": email,
            "phone": phone,
            "location": location,
            "linkedin": f"linkedin.com/in/{name.lower().replace(' ', '-')}-{role.split()[0].lower()}"
        },
        "summary": summary,
        "education": education,
        "experience": experience,
        "skills": skills,
        "certifications": certifications,
        "achievements": random.sample(achievements, k=random.randint(2, 3)),
        "publications": publications
    }

def create_docx(resume, filename):
    doc = Document()
    set_docx_margins(doc)
    
    # Header with name and role
    header = doc.add_paragraph()
    header.paragraph_format.space_after = Pt(6)
    name_run = header.add_run(resume['name'])
    name_run.bold = True
    name_run.font.size = Pt(14)
    name_run.font.name = 'Calibri'
    name_run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Calibri')
    
    role_run = header.add_run(f"\n{resume['role']}")
    role_run.bold = True
    role_run.font.size = Pt(12)
    role_run.font.color.rgb = RGBColor(67, 114, 196)  # Fixed: Using RGBColor object
    
    header.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    
    # Contact information
    contact = doc.add_paragraph()
    contact.paragraph_format.space_after = Pt(12)
    contact.add_run(f"{resume['contact']['email']} | {resume['contact']['phone']} | {resume['contact']['location']} | {resume['contact']['linkedin']}")
    contact.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    
    # Professional Summary
    add_section_header(doc, "Professional Summary")
    doc.add_paragraph(resume['summary'])
    
    # Education
    add_section_header(doc, "Education")
    for edu in resume['education']:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        degree_run = p.add_run(edu['degree'])
        degree_run.bold = True
        p.add_run(f"\n{edu['university']} | {edu['year']}")
    
    # Professional Experience
    add_section_header(doc, "Professional Experience")
    for exp in resume['experience']:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        
        # Company and role
        company_run = p.add_run(f"{exp['company']} | {exp['location']}")
        company_run.bold = True
        p.add_run(f"\n{exp['role']} | {exp['duration']}")
        
        # Projects
        for project in exp['projects']:
            doc.add_paragraph(f"\nProject: {project['name']} ({project['duration']})", style='List Bullet')
            doc.add_paragraph(f"Description: {project['description']}")
            
            # Tech Stack
            tech_stack_para = doc.add_paragraph("Tech Stack: ")
            tech_stack_para.add_run(", ".join(project['tech_stack'])).italic = True
            
            # Key Contributions
            doc.add_paragraph("Key Contributions:", style='List Bullet')
            for contribution in project['contributions']:
                doc.add_paragraph(contribution, style='List Bullet 2')
    
    # Technical Skills
    add_section_header(doc, "Technical Skills")
    skills_para = doc.add_paragraph()
    skills_para.add_run(", ".join(resume['skills']))
    
    # Certifications
    if resume['certifications']:
        add_section_header(doc, "Certifications")
        for cert in resume['certifications']:
            doc.add_paragraph(cert, style='List Bullet')
    
    # Achievements
    if resume['achievements']:
        add_section_header(doc, "Achievements")
        for achievement in resume['achievements']:
            doc.add_paragraph(achievement, style='List Bullet')
    
    # Publications
    if resume.get('publications'):
        add_section_header(doc, "Publications")
        for pub in resume['publications']:
            doc.add_paragraph(f"\"{pub['title']}\" - {pub['venue']} ({pub['year']})", style='List Bullet')
    
    doc.save(filename)

def save_resumes(resumes):
    os.makedirs("resumes", exist_ok=True)
    
    for i, resume in enumerate(resumes, 1):
        docx_filename = f"resumes/resume_{i}_{resume['name'].replace(' ', '_')}.docx"
        create_docx(resume, docx_filename)
        
        pdf_filename = f"resumes/resume_{i}_{resume['name'].replace(' ', '_')}.pdf"
        
        with tempfile.NamedTemporaryFile(suffix='.html', delete=False, mode='w+', encoding='utf-8') as temp_html:
            html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{resume['name']} - Resume</title>
    <style>
        body {{ 
            font-family: 'Calibri', Arial, sans-serif; 
            line-height: 1.6; 
            margin: 0;
            padding: 20px;
            color: #333;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
        }}
        h1 {{ 
            color: #2E86C1; 
            margin-bottom: 5px;
            font-size: 24px;
        }}
        h2 {{
            color: #3498DB;
            border-bottom: 2px solid #3498DB;
            padding-bottom: 3px;
            font-size: 18px;
            margin-top: 20px;
        }}
        .header {{
            text-align: center;
            margin-bottom: 20px;
        }}
        .contact {{
            text-align: center;
            margin-bottom: 20px;
            font-size: 14px;
        }}
        .role {{
            color: #4472C4;
            font-weight: bold;
            margin-bottom: 10px;
        }}
        .company {{
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .duration {{
            font-style: italic;
            color: #666;
        }}
        .project {{
            margin-bottom: 15px;
        }}
        .project-title {{
            font-weight: bold;
        }}
        .tech-stack {{
            font-style: italic;
        }}
        ul {{
            margin-top: 5px;
            padding-left: 20px;
        }}
        li {{
            margin-bottom: 5px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{resume['name']}</h1>
            <div class="role">{resume['role']}</div>
            <div class="contact">
                {resume['contact']['email']} | {resume['contact']['phone']} | {resume['contact']['location']} | {resume['contact']['linkedin']}
            </div>
        </div>
        
        <h2>Professional Summary</h2>
        <p>{resume['summary']}</p>
        
        <h2>Education</h2>
"""
            
            for edu in resume['education']:
                html_content += f"""
        <p><strong>{edu['degree']}</strong><br>
        {edu['university']} | {edu['year']}</p>
"""
            
            html_content += """
        
        <h2>Professional Experience</h2>
"""
            
            for exp in resume['experience']:
                html_content += f"""
        <div class="company">{exp['company']} | {exp['location']}</div>
        <div>{exp['role']} | <span class="duration">{exp['duration']}</span></div>
"""
                
                for project in exp['projects']:
                    html_content += f"""
        <div class="project">
            <div class="project-title">Project: {project['name']} ({project['duration']})</div>
            <p>{project['description']}</p>
            <p class="tech-stack">Tech Stack: {", ".join(project['tech_stack'])}</p>
            <div>Key Contributions:</div>
            <ul>
"""
                    
                    for contribution in project['contributions']:
                        html_content += f"""
                <li>{contribution}</li>
"""
                    
                    html_content += """
            </ul>
        </div>
"""
            
            html_content += f"""
        <h2>Technical Skills</h2>
        <p>{", ".join(resume['skills'])}</p>
"""
            
            if resume['certifications']:
                html_content += """
        <h2>Certifications</h2>
        <ul>
"""
                for cert in resume['certifications']:
                    html_content += f"""
            <li>{cert}</li>
"""
                html_content += """
        </ul>
"""
            
            if resume['achievements']:
                html_content += """
        <h2>Achievements</h2>
        <ul>
"""
                for achievement in resume['achievements']:
                    html_content += f"""
            <li>{achievement}</li>
"""
                html_content += """
        </ul>
"""
            
            if resume.get('publications'):
                html_content += """
        <h2>Publications</h2>
        <ul>
"""
                for pub in resume['publications']:
                    html_content += f"""
            <li>"{pub['title']}" - {pub['venue']} ({pub['year']})</li>
"""
                html_content += """
        </ul>
"""
            
            html_content += """
    </div>
</body>
</html>
"""
            temp_html.write(html_content)
            temp_html.flush()
        
        try:
            options = {
                'encoding': 'UTF-8',
                'quiet': '',
                'margin-top': '0.5in',
                'margin-right': '0.5in',
                'margin-bottom': '0.5in',
                'margin-left': '0.5in',
                'page-size': 'A4',
                'dpi': 300
            }
            from_file(temp_html.name, pdf_filename, options=options)
        finally:
            os.unlink(temp_html.name)

if __name__ == "__main__":
    print(f"Generating {NUM_RESUMES} professional resumes in DOCX and PDF formats...")
    resumes = [generate_resume() for _ in range(NUM_RESUMES)]
    save_resumes(resumes)
    print(f"Successfully generated {NUM_RESUMES} resumes in 'resumes' directory.")